# JARVIS OS · 0.8.0

**Przejęcie przez Codexa:** zacznij od [00_START_HERE.md](00_START_HERE.md), a gotowe zlecenie znajdziesz w [PROMPT_CODEX.md](PROMPT_CODEX.md). Maszynowy stan: [PROJECT_STATUS.json](PROJECT_STATUS.json). To istniejący projekt do rozwijania, nie szablon do napisania od nowa.


Osobisty, modułowy asystent dla Andreasa, zintegrowany z AutoLogika OS. Lokalny projekt Python/FastAPI + SQLite + Control Center. Rozwija starter 0.1 oraz wersje 0.2–0.3. **To nadal MVP** — wbudowane adaptery DEMO są oddzielone od rzeczywistych odczytów.

## Szybki start na Windows

Zainstaluj Python 3.12, rozpakuj projekt do osobnego katalogu i w PowerShell uruchom:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\start.ps1
```

Skrypt tworzy `.venv`, generuje klucz właściciela w `.env`, instaluje przypięte zależności, uruchamia testy i Core. Otwórz http://127.0.0.1:8000 i wklej JARVIS_API_KEY. Klucz jest tylko w pamięci karty. Nie zastępuj plików AutoLogiki tym projektem.

Linux / ręcznie:

```bash
python3.12 -m venv .venv
source .venv/bin/activate
pip install -r requirements-dev.txt
cp .env.example .env
python -c "import secrets; print(secrets.token_urlsafe(32))"
# Wstaw wygenerowany klucz do JARVIS_API_KEY w .env.
python -m pytest -q
python -m uvicorn jarvis.main:app --host 127.0.0.1 --port 8000
```

`requirements.lock` przypina także zależności pośrednie; requirements.txt używa go jako constraints. Lock nie jest audytem bezpieczeństwa ani plikiem z hashami pakietów. Wersje sprawdzono razem w izolowanym środowisku Python 3.12.

## Co działa

| Moduł | Stan |
|---|---|
| Core i Control Center | Trwała baza, panel responsywny z 11 zakładkami, health i audyt |
| MCP | Streamable HTTP: sesja, discovery i wywołania sprawdzonych odczytów przez oficjalny SDK; bez OAuth/stdio |
| OpenAPI | Obsługiwany podzbiór: GET, operationId, skalarne parametry, lokalny schemat bez $ref |
| Uprawnienia | Klucz właściciela i ograniczone tokeny z datą ważności, cofnięciem i przechowywaniem skrótu |
| Home Assistant | Rzeczywisty czytnik stanów jawnie wskazanych encji; bez sterowania |
| WhatsApp | Weryfikowany webhook Twilio, inbox, deduplikacja, szkice; bez wysyłki i Calling |
| AutoLogika | Audyt 681f7f5, istniejące GET zleceń i osobny czytnik 8 domen z przygotowanej kopii schematu 18; bez zapisów |
| Rozmowa i pamięć | DEMO/Ollama, katalog modeli, trwałe sesje i historia, kontekst sesji, eksport/usuwanie i ręczna retencja; jawne podsumowanie warsztatu |
| Zmiany rozmową | „zapamiętaj …”, „ustaw imię Jan”, „przypominaj co 60 minut: Sprawdź części”; propozycje, akceptacja i rollback |
| Automatyzacje | Lokalny tick, worker, opcjonalny n8n i nieaktywny workflow do importu |
| Operacje | Kopie SQLite z SHA-256; kopia przed migracją do schematu 0.4, Docker i testy CI do uruchomienia |

Nie zaimplementowano komend do bramy/świateł ani wysyłania wiadomości WhatsApp. Od modelu nie zależą uprawnienia i zgody. Narzędzia MCP na liście właściciela muszą być wcześniej sprawdzone — sama adnotacja serwera `readOnlyHint` nie daje uprawnień i nie dowodzi braku skutków ubocznych.

## Test integracji bez kont i urządzeń

W drugim terminalu uruchom syntetyczne laboratorium:

```bash
python -m uvicorn examples.lab_server:app --host 127.0.0.1 --port 8765
```

W panelu Integracje zarejestruj plugin z protocol `mcp` albo `openapi`, otwórz Konfiguracja i użyj odpowiedniego pliku `examples/lab.*.config.json`. Zapis wyłącza plugin: przejrzyj konfigurację, włącz go, wybierz Odkryj narzędzia i wywołaj `read_temperature` z argumentami `{}`. To prawdziwy transport do lokalnego serwera, ale dane z niego są syntetyczne. Test automatyczny robi to samo z osobnym procesem serwera na losowym porcie.

## Rozmowy i kopia warsztatu

W Rozmowie utwórz osobną sesję, wybierz model z katalogu właściciela i wracaj do historii po restarcie. Historia nieudanych zapytań jest oznaczona; nie trafia do kontekstu modelu. Można zmienić tytuł, eksportować i usunąć sesję. Katalog definiuje OLLAMA_ALLOWED_MODELS — nie instaluje modeli. Modele z końcówką :cloud wymagają dodatkowego jawnego włączenia.

Bez dostępu do warsztatu przetestuj osiem domen na syntetycznej kopii:

```bash
python -m examples.workshop_fixture
python scripts/import_autologika.py --source data/lab/autologika-fixture.db
```

Ustaw AUTOLOGIKA_SNAPSHOT_ENABLED=true w .env i zrestartuj Core. Zakładka AutoLogika · kopia pokazuje dane offline. Dla finansów laboratorium wybierz miesiąc 2026-10. Przy zaznaczeniu checkboxa w rozmowie model otrzyma agregaty finansowe/statusowe i datę kopii, bez list klientów. Pełna instrukcja, ograniczenia i import rzeczywistej bazy w środę: docs/ROZMOWY-I-WARSZTAT-v0.4.md.

## Docker

Po ustawieniu klucza właściciela w `.env`:

```bash
docker compose config
docker compose up --build -d
```

Panel pozostaje na 127.0.0.1:8000. Dane są w `jarvis-data`. Nie używaj `down -v`, jeśli mają pozostać. Do workera utwórz w panelu token `scheduler:tick`, wpisz w `.env` jako JARVIS_SCHEDULER_TOKEN, następnie `docker compose --profile automation up --build -d`. Klucz właściciela nie jest przekazywany workerowi.

Dla n8n ustaw osobny N8N_ENCRYPTION_KEY i sprawdzony aktualny N8N_IMAGE, uruchom profil n8n. Zaimportuj `examples/n8n-tick.workflow.json`, przypisz w węźle HTTP poświadczenie Header Auth: `X-Jarvis-Key` z tokenem `scheduler:tick`. Workflow jest nieaktywny i wymaga sprawdzenia w zainstalowanej wersji n8n. n8n jest source-available; sprawdź licencję dla przyszłego hostowania komercyjnego.

W kontenerze `127.0.0.1` oznacza kontener. Dla usług Windows użyj `host.docker.internal` i dodaj jego **konkretny adres lub odpowiedni wąski zakres** do JARVIS_NETWORK_ALLOWLIST. Sekrety pluginów JARVIS_PLUGIN_SECRET_* wymagają jawnego przekazania w Compose override — nie są automatycznie eksportowane z pliku `.env` do kontenera.

## Dokumentacja

- `docs/RAPORT.md` — aktualny stan, testy, wymagane konta i plan na środę 28.10.
- `docs/ROZMOWY-I-WARSZTAT-v0.4.md` — historia, modele, retencja, kopia SQLite i zakres 8 domen.
- `docs/MODULY-v0.3.md` — konfiguracja MCP/OpenAPI, sieci, HA, tokenów i WhatsApp.
- `docs/AUDYT_AUTOLOGIKA.md` i `docs/autologika-evidence.json` — rzeczywisty kontrakt AutoLogiki, commit i dowody.
- `docs/ARCHITEKTURA.md` — plan wszystkich 11 obszarów i decyzje.
- `docs/API.md` — kontrakt aktualnego Core.
- `docs/OPERACJE.md` — backup/restore, aktualizacje, Windows i telefon.
- `CHANGELOG.md` — zmiany wersji, `docs/history/` — raport poprzedniej wersji.

Nie zmodyfikowano repozytorium produkcyjnego AutoLogiki. Nie podłączono rzeczywistej instalacji warsztatu, domu ani konta Twilio. Pełne zapisy AutoLogiki, fizyczne sterowanie i połączenia WhatsApp wymagają kolejnych etapów. Kopia SQLite nie daje synchronizacji na żywo ani pełnego parytetu z ekranami desktopu.

## Nowe w 0.5

Panel „Głos lokalny”: jawny upload WAV i synteza przez zewnętrzne usługi Wyoming. Tekst wymaga sprawdzenia; nie wykonuje poleceń. Panel pamięci: FTS5 i opcjonalne hybrydowe wyszukiwanie przez lokalne embeddingi Ollama. Zapis pamięci nadal ręczny; wyszukiwarka nie zmienia automatycznie kontekstu rozmów.

Konfiguracja: [Głos i pamięć](docs/GLOS-I-PAMIEC-v0.5.md). Przegląd kodu/licencji projektów: [Przegląd repozytoriów](docs/OPEN-SOURCE.md). Bieżący stan i środowy plan: [raport](docs/RAPORT.md). Wymagany Python 3.12; Wyoming 1.10.2 korzysta z audioop, usuniętego w Pythonie 3.13.

## Nowe w 0.6

Zakładka Telefonia: ustawienia godzin przekazywania do właściciela, numery, urlopy, DND i podgląd przyczyn decyzji. **Bez wykonywania rozmów** — konfiguracja nie aktywuje przekierowania Play. Instrukcja: [Telefonia](docs/TELEFONIA-v0.6.md). 112 testów pytest, schemat Core 6.

## Nowe w 0.7

Recepcja · laboratorium: tekstowa rozmowa, pierwsza prośba i naleganie, oczekiwanie na właściciela, symulacja przyjęcia/odmowy/nieodebrania i trwałe zgłoszenia. **Bez operatora i analizy AI** — jawne reguły testowe, bez zapisu do AutoLogiki. [Instrukcja](docs/RECEPCJA-v0.7.md). 127 testów, schemat Core 7.

## Nowe w 0.8 i Codex Cloud

Opcjonalna analiza recepcji przez Ollama z JSON Schema, cytatami i uzupełnianiem danych. **Integracja zaimplementowana, jakość rzeczywistego modelu niesprawdzona.** [Instrukcja](docs/ANALIZA-RECEPCJI-v0.8.md). 147 testów; schemat7.

Przeniesienie do osobnego repozytorium i kontynuacja: [CODEX-HANDOFF](docs/CODEX-HANDOFF.md), AGENTS.md i `python3.12 scripts/cloud_setup.py`. Pakiet nie został automatycznie wysłany na GitHub ani uruchomiony w Cloud.

## Paczka przekazania 0.8-handoff.1

ZIP ma pliki repo bezpośrednio w głównym katalogu. HANDOFF-MANIFEST.json zawiera commit źródłowy i SHA256 dostarczonych plików. Przed pierwszą zmianą: `python3 scripts/verify_handoff.py`. Po rozpoczęciu kodowania suma zmienionego pliku naturalnie się różni; manifest nie jest podpisem ani stałym testem CI. Historia .git, sekrety, bazy i modele nie są pakowane.

Ponowne utworzenie paczki z czystego, zapisanego repo: `python3 scripts/package_handoff.py --output ../JARVIS-OS.zip`. Nie pakuj ręcznie całego katalogu roboczego z danymi.
