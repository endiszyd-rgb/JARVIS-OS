# Zmiany

## 0.8-handoff.1 — 22.10.2026

- Płaski ZIP z instrukcją startową, gotowym poleceniem, maszynowym statusem11obszarów, zatwierdzonymi decyzjami i kolejką z kryteriami odbioru.
- Powtarzalne pakowanie wyłącznie śledzonych plików i weryfikacja SHA256 dostarczonego źródła.
- Brak zmian zachowania aplikacji, wersja0.8.0/schema7. Bazowe147testów.

## 0.8.0 — 22.10.2026

- Opcjonalna analiza recepcji Ollama JSON Schema: pochodzenie cytatów/faktów, niepewność, granice uprawnień i kontrola rewizji.
- Panel analizy, model na allowliście, brak automatycznego przechodzenia do heurystyki przy awarii.
- Pakiet przekazania do Codex Cloud: AGENTS.md, dokument stanu i skrypt setup/checks.
- 147 testów, lokalny test HTTP i DOM; brak rzeczywistej inferencji i aktywowanej telefonii. Schemat bazy nadal7.

## 0.7.0 — 22.10.2026

- Laboratorium recepcji, stany rozmowy, oddzielne podsumowanie właściciela i zgłoszenia.
- Ponowna ocena dostępności przed akceptacją, obsługa odmowy i braku odpowiedzi, idempotencja i transakcje.
- Osobny panel, migracja Core 7, usuwanie danych rozmowy i 127 testów. Bez operatora, połączeń i klasyfikacji AI.

## 0.6.0 — 22.10.2026

- Panel Telefonia i API właściciela: tygodniowy grafik, urlop/wyjątki, DND, numery i podgląd eskalacji bez operatora.
- Europe/Warsaw z fallbackiem tzdata, rewizje ustawień, migracja do schematu 6 z backupem.
- 112 testów i test DOM z działającym Core; brak rzeczywistych rozmów.

## 0.5.0 — 22.10.2026

- Wyoming STT/TTS przez jawne pliki, lokalny FTS5 i opcjonalna pamięć hybrydowa przez Ollama.
- Przegląd repozytoriów i licencji, limity ciał HTTP i zdarzeń audio, schemat 5.
- 93 testy; rzeczywiste silniki i Windows nadal wymagają sprawdzenia.

## 0.4.0 — 22.10.2026

- Trwałe sesje i wiadomości, tytuły, eksport JSON, usuwanie kaskadowe oraz podgląd/aplikacja ręcznej retencji.
- Katalog nazw modeli z listy właściciela, faktyczny wybór modelu per sesja i respektowanie domyślnego dostawcy; brak automatycznego pobierania modeli.
- Ograniczony kontekst udanych wiadomości bieżącej sesji, blokada równoległych tur, zapis niepowodzeń i odzyskanie starej blokady.
- Most tylko do odczytu 8 domen z jawnie przygotowanej kopii schematu AutoLogiki 18; spójny import SQLite backup API, manifest i SHA-256, bez zmian repozytorium AutoLogiki.
- Raporty i finanse z kopii mogą być jawnie dołączone do rozmowy; bez automatycznego przekazywania list klientów.
- Zakładka AutoLogika · kopia, rozwinięty panel rozmów, syntetyczna baza warsztatu do testów i kopia przed migracją Core do schematu 4.
- 83 testy pytest oraz test zachowania nowych widoków DOM.

## 0.3.0 — 22.10.2026

- Transport MCP Streamable HTTP przez oficjalny Python SDK 1.30: inicjalizacja sesji, lista narzędzi i wywołania jawnie zatwierdzonych odczytów. Bez stdio i uruchamiania procesów pluginów.
- Ograniczony importer OpenAPI 3.x: GET, operationId, skalarne parametry path/query i walidacja; bez zewnętrznych referencji, requestBody, zapisów i automatycznego pobierania specyfikacji.
- Konfiguracja pluginów w panelu, sekrety wskazywane nazwą zmiennej .env. Zmiana konfiguracji wyłącza plugin do ponownego włączenia.
- Kontrola sieci: jawne zakresy IP, rozwiązywanie DNS z przypięciem IP, kontrola Host/SNI, blokada przekierowań oraz limit odpowiedzi.
- Ograniczone tokeny z terminem ważności i cofnięciem; sekret pokazywany tylko raz, w bazie SHA-256. Scheduler nie wymaga klucza właściciela.
- Czytnik Home Assistant: allowlista encji, tylko stany, bez usług sterujących.
- Twilio/WhatsApp: podpisany webhook, dokładny publiczny adres HTTPS, allowlista nadawców i konta, deduplikacja także po usunięciu wiadomości, inbox i niewysyłane szkice.
- Zakładki Dom, WhatsApp i Dostęp; laboratorium integracyjne bez kont; nieaktywny szablon workflow n8n; lock zależności i automatyczna kopia przed rozszerzeniem schematu 0.2 → 0.3.
- Testy obejmują pełną ścieżkę Core → osobny proces serwera MCP/OpenAPI na localhost.

## 0.2.0

Pierwszy Core i panel, audyt AutoLogiki, rzeczywisty adapter GET zleceń, DEMO integracji, pamięć/Ollama, propozycje i rollback, scheduler, backup oraz 36 testów. Raport historyczny: docs/history/RAPORT-v0.2.md.
