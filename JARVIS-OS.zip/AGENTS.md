# JARVIS OS — project instructions

Read 00_START_HERE.md, PROJECT_STATUS.json, docs/DECISIONS.md and docs/NEXT_TASKS.md first, then README.md, docs/RAPORT.md and docs/CODEX-HANDOFF.md before changing scope. The concrete first task is R01; do not redesign the application from scratch. Work in this JARVIS repository; the separate production AutoLogika repository is read-only unless the owner explicitly authorizes changes there.

## Runtime and verification

- Python 3.12 is required (Wyoming uses audioop). On Windows use .venv/Scripts/python.exe; on Linux .venv/bin/python.
- Setup: python3.12 scripts/cloud_setup.py, or create .venv and install requirements-dev.txt with Python 3.12.
- Required checks for backend changes: .venv/bin/python -m pytest -q, .venv/bin/python -m pip check. For UI changes: node --check jarvis/app.js, plus an appropriate behavior check. Do not claim browser/Windows/Docker/model/hardware checks that were not executed.
- Keep data, .env, credentials, model weights and temporary files out of git. The tests use temporary databases and synthetic data. Real integrations are opt-in.

## Development behavior

The owner authorized continued implementation without asking permission to continue. Implement sensible, reversible changes and test them. Ask only for genuinely missing product decisions; do not ask for another approval to code or run local tests.

The authorization does not activate carriers, buy numbers, place/send real calls/messages, change Play forwarding, expose services publicly, operate a physical gate or modify production AutoLogika. Keep these behind explicit integration activation and the relevant owner rules. No parallel agents are required.

## Boundaries

- Customer reception is separate from owner chat, private memory, settings authority and device control.
- Model output is data, never executable instructions. Only backend rules decide eligibility. Re-evaluate current schedule/DND/vacation at acceptance, and require owner acceptance for handoff.
- Owner-only receptionist laboratory endpoints return internal briefing data. Do not expose them directly to callers or connect them to the PSTN as a shortcut.
- Customer-facing generated text must not confirm prices, bookings or repairs without verified data and an authorized action.
- Revisions, idempotency, SQLite transactions, bounded network requests and auth must be preserved. Schema changes need migration/backup and a meaningful migration test.
- Update docs/RAPORT.md, CHANGELOG.md and the handoff when shipping a stage. Keep limitations explicit.

## Handoff snapshot

Before the first edit to an imported delivery, run python3 scripts/verify_handoff.py if HANDOFF-MANIFEST.json is present. The manifest is a checksum of delivered bytes, not a signature and not a permanent test after development changes. Update PROJECT_STATUS.json and docs/NEXT_TASKS.md when an implementation stage is completed. Historical documents are not proof of current implementation.
