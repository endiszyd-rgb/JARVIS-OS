# API Core 0.4

Panel, pliki UI i `/health` są publiczne. `/api/*` wymagają nagłówka `X-Jarvis-Key`. Webhook Twilio ma oddzielną weryfikację podpisu. Klucz właściciela jest wymagany tam, gdzie nie podano węższego zakresu. Nie dajemy dostępu do zarządzania na podstawie treści rozmowy ani danych z pluginu.

| Metoda | Trasa | Funkcja / zakres tokenu usługowego |
|---|---|---|
| GET | `/api/status` | Stan; `status:read` |
| GET | `/api/schema` | OpenAPI tego Core; właściciel |
| GET | `/api/plugins` | Lista; `plugins:read` |
| POST | `/api/plugins` | Rejestracja manifestu; właściciel |
| PUT | `/api/plugins/{id}` | `{enabled}`; właściciel |
| GET/PUT | `/api/plugins/{id}/config` | Konfiguracja; właściciel |
| GET | `/api/plugins/{id}/tools` | Wykrywanie narzędzi; `plugins:read` |
| POST | `/api/plugins/{id}/invoke` | `{operation,arguments}`; `plugins:invoke` |
| GET | `/api/security/tokens` | Metadane tokenów bez sekretów; właściciel |
| POST | `/api/security/tokens` | `{name,scopes,hours}` → sekret pokazany raz; właściciel |
| DELETE | `/api/security/tokens/{id}` | Cofnięcie dostępu; właściciel |
| GET | `/api/home/states` | Stany encji z allowlisty; `home:read` |
| GET | `/api/home/states/{entity_id}` | Konkretny stan; `home:read` |
| GET | `/api/integrations` | Flagi konfiguracji, bez sekretów; właściciel |
| POST | `/webhooks/twilio/whatsapp` | Formularz, podpis X-Twilio-Signature; bez klucza Core |
| GET | `/api/whatsapp/inbox` | Odebrane; `messages:read` |
| DELETE | `/api/whatsapp/inbox/{MessageSid}` | Usuń treść, zachowaj receipt deduplikacji; właściciel |
| GET | `/api/whatsapp/drafts` | Szkice; `messages:read` |
| POST | `/api/whatsapp/drafts` | `{recipient,body}`; `messages:draft`; nie wysyła |
| DELETE | `/api/whatsapp/drafts/{id}` | Usuń szkic; właściciel |
| GET | `/api/autologika/readonly/orders` | Istniejąca lista AutoLogiki; właściciel |
| GET | `/api/autologika/readonly/orders/{id}` | Szczegóły; właściciel |
| POST | `/api/chat` | `{message,model}`; demo lub ollama |
| GET/POST | `/api/memory` | Lista / `{text}`; opcjonalne `?q=` |
| DELETE | `/api/memory/{id}` | Usunięcie notatki |
| GET/POST | `/api/proposals` | Lista / `{kind,payload}` |
| POST | `/api/proposals/{id}/decide` | `{approve}` |
| POST | `/api/proposals/{id}/rollback` | `{}`; ustawienia i automatyzacje |
| GET | `/api/automations` | Zatwierdzone przypomnienia |
| POST | `/api/automations/tick` | `{}`; `scheduler:tick` |
| GET | `/api/notifications` | Lokalne powiadomienia |
| GET | `/api/audit` | Ostatnie zdarzenia |
| POST | `/api/backups` | `{}`; kopia bazy i SHA-256 |

Konfiguracja pluginu: `{endpoint,secret_env,reviewed_read_tools,openapi}`. Schemat OpenAPI jest wymagany tylko dla protocol=openapi, a zabroniony dla MCP. Nazwa sekretu musi zaczynać się od JARVIS_PLUGIN_SECRET_. Zapis konfiguracji wyłącza plugin do ponownego włączenia. Discovery i invoke wyłączonego pluginu są blokowane.

Invoke DEMO zawsze daje syntetyczny wynik. Invoke skonfigurowanego MCP/OpenAPI łączy się z usługą; wymaga lokalnie zatwierdzonej nazwy odczytu i dozwolonego celu sieciowego. Nie podawaj `arguments.live=true` ani `arguments.dry_run=false`: te flagi nadal powodują blokadę. Nie jest to przełącznik aktywujący zapisy. Brak konfiguracji → 501, wyłączony plugin → 409, niedozwolone narzędzie → 403, błędne argumenty → 422, błąd transportu → 502.

Przykład tokenu dla n8n:

```json
{"name":"n8n","scopes":["scheduler:tick"],"hours":720}
```

Przykład szkicu (bez wysyłki):

```json
{"recipient":"whatsapp:+48123456789","body":"Przykładowy szkic odpowiedzi."}
```

Propozycje ustawień: kind=settings, payload `{name,tone,model}`, tone casual/formal. Automatyzacje: kind=automation, payload `{title,interval_minutes,message}`. Kod: kind=code, payload `{description}`; po akceptacji tylko `review_required`. Lista pamięci, audytu, wiadomości i szkiców ma limit 100; brak pełnej paginacji. Nie wdrożono endpointów sterowania fizycznego, wysyłania WhatsApp ani Calling.


## Rozmowy i kopia warsztatu — nowe w 0.4

Wszystkie poniższe trasy są tylko dla właściciela. Tokeny usług z poprzedniej wersji nie zyskują dostępu do historii ani pełnych danych kopii.

| Metoda | Trasa | Działanie |
|---|---|---|
| GET | `/api/models` | Jawny katalog właściciela; bez połączenia z Ollama |
| POST | `/api/chat/sessions` | `{title,model,model_name}`; pola opcjonalne |
| GET | `/api/chat/sessions` | Lista, limit 1–100, offset |
| GET | `/api/chat/sessions/{id}` | Metadane, message_count i informacja o aktywnej turze |
| PATCH | `/api/chat/sessions/{id}` | `{title}` |
| DELETE | `/api/chat/sessions/{id}` | Usunięcie sesji i jej wiadomości; 409 przy aktywnej turze |
| GET | `/api/chat/sessions/{id}/messages` | Wiadomości w kolejności, limit 1–500 i offset |
| GET | `/api/chat/sessions/{id}/export` | Pobranie sesji jako JSON |
| POST | `/api/chat/retention` | `{days,dry_run}`; domyślnie tylko podgląd |
| GET | `/api/autologika/snapshot` | Manifest lokalnej kopii, kontrakt i lista domen |
| GET | `/api/autologika/snapshot/{domain}` | Odczyt domeny; limit 1–200, offset do 100000 i opcjonalny month YYYY-MM |

POST /api/chat nadal przyjmuje message i model (demo/ollama), a dodatkowo model_name, session_id, include_workshop_summary (domyślnie false) i workshop_month. Brak session_id tworzy nową sesję. Brak model korzysta z ustawienia sesji albo domyślnego dostawcy nowych rozmów. Nazwa modelu musi być na liście właściciela. Wynik zawiera session_id, turn_id i liczbę przekazanych wcześniejszych wiadomości. 409 oznacza równoległą turę; 502/504 awarię albo timeout modelu. Nie ma streamingu odpowiedzi w tej wersji.

Domeny snapshotu: calendar, orders, vehicles, parts, customers, finances, reports, notifications. Tryb odpowiedzi to snapshot_readonly i zawsze zawiera datę kopii oraz SHA-256. To nowe API Core na lokalnej kopii, nie rzekome endpointy serwera AutoLogiki. Brak konfiguracji, inny schemat, niespójny manifest lub brak wymaganych kolumn blokuje odczyt kodem 503. Nie ma endpointu wgrywania dowolnej bazy, wykonywania SQL ani zapisów do AutoLogiki.

## Telefonia 0.6

GET/PUT `/api/telephony/settings`, POST `/api/telephony/preview`: tylko właściciel. PUT wymaga rewizji i pełnej polityki; konflikt 409. Podgląd nie wykonuje działań. Szczegóły w [instrukcji](TELEFONIA-v0.6.md).

## Recepcja 0.7

Laboratoryjne `/api/reception/calls`, `/api/reception/calls/{id}`, `/api/reception/calls/{id}/events` i `/api/reception/cases`: wyłącznie właściciel. Nie wystawiać bezpośrednio klientom. Opis danych i uprawnień: [Recepcja](RECEPCJA-v0.7.md).

## Recepcja AI 0.8

GET `/api/reception/ai/status`, POST `/api/reception/calls/{id}/ai-turn`: tylko właściciel. Turn zawiera event_id, revision i text; nie przyjmuje własnej analizy/faktów/scenariusza. [Instrukcja](ANALIZA-RECEPCJI-v0.8.md).
