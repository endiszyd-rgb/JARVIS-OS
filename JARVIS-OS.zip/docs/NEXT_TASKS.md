# Kolejka wykonawcza dla następnej sesji

Wersja przekazania 0.8-handoff.1. Pierwsze zadanie: R01. Stan bieżący w PROJECT_STATUS.json; zamknięcie zadania wymaga kodu, dowodów i aktualizacji stanu. Te opisy są docelowymi wymaganiami — nie implementacją.

## R01 — ewaluacja polskiej recepcji (START TUTAJ)

**Problem:** walidacja JSON/cytatów i testy transportu nie mierzą jakości rozumienia polskiej rozmowy przez model.

**Kod wejściowy:** jarvis/reception_ai.py, jarvis/reception.py, jarvis/telephony.py, tests/test_reception_ai.py, docs/ANALIZA-RECEPCJI-v0.8.md.

**Dostarcz:** wersjonowany syntetyczny zestaw co najmniej 25 rozmów/przypadków, CLI runner i raport JSON/Markdown. Uwzględnij rutynę, pierwszą prośbę, naleganie z odrzuceniem pomocy, kryzys po naprawie, negację, cytat, przeszłość, hipotezę, zdenerwowanie bez kryzysu, pomyłkę numeru, brak polskich znaków, brak danych, błędny telefon i prompt injection. Oczekiwania muszą oceniać semantykę, wydobycie faktów i zakaz wykonania działań, nie tylko składnię.

**Kryteria odbioru:**

- Runner używa istniejącej analizy, jawnie wybranego modelu i bezpiecznej sieci; bez auto-pobierania modeli, operatora i danych klientów.
- Wynik rozróżnia błędny schemat, zmyślony cytat/fakt, niepewność, błędną intencję oraz niebezpieczną nadmierną eskalację. Pokazuje liczniki i konkretne niezaliczone przykłady, nazwę modelu, wersję zestawu i rzeczywiste źródło odpowiedzi.
- Jest tryb walidacji zestawu bez modelu. Błąd środowiska nie jest wynikiem jakości. Wyniki fixture/symulacji są wyraźnie oznaczone i nie są agregowane jako sukces rzeczywistego AI.
- Testy runnera na kontrolowanym serwerze obejmują sukces, błąd modelu, niepoprawną odpowiedź, raport i brak działań ubocznych. Nie kopiuj implementacji do asercji.
- Bazowe testy pozostają zielone. Realny eval tylko jeśli dostępna jest rzeczywista Ollama/model. W innym przypadku pozostaw „jakość niesprawdzona” i przejdź dalej.

## R02 — ustawienia i źródła pamięci osobistej

Oddziel politykę pamięci od settings modelu i recepcji. Panel: auto/manual, kategorie, retencja, źródła, poprawianie/usuwanie, „nie pamiętaj”. Migracja zachowuje stare notatki jako manualne. Najpierw źródła i polityka, dopiero potem ograniczona ekstrakcja. Sekrety, dane płatnicze i dane klientów wykluczone. Ochrona przed duplikatami i fałszywym nadpisaniem; korekty mają historię/źródło. Testy obejmują blokadę zapisu, restart, usunięcie, stare dane, błędną ekstrakcję i izolację recepcji.

## R03 — sesja audio bez wake-word na pierwszym etapie

Warstwa sesji: idle/listening/processing/speaking, ręczna aktywacja, zakończenie/anulowanie, regulowana cisza30s i przerwanie wypowiedzi. Testy zegara i izolacji sesji. Mikrofon przeglądarki ma działać tylko po aktywacji i zwalniać zasoby. Nie udawaj testu hardware przy fixture. Wake-word dopiero po ocenie licencji modelu oraz projektu lokalnego nasłuchu. Docelowo satelity dom/warsztat i prywatne wyjście, bez ujawniania finansów klientom.

## R04 — kontrakt transportu telefonii

Interfejs adaptera, oddzielne kanały klient/właściciel, idempotentne eventy, oczekiwanie, prywatny briefing, akceptacja, timeout i limity prób/kosztów. Najpierw transport laboratoryjny i pełne testy. Nie udostępniaj właścicielskiego obiektu recepcji klientowi. Rzeczywisty operator, zakup numeru, Play i transfer wymagają kont/konfiguracji i osobnego uruchomienia. Szkic adaptera nie jest działającym połączeniem.

## R05 — MQTT/ESP32/n8n i powiadomienia

Najpierw odczyt czujników i laboratorium brokera, rozróżnienie świeżych/starych danych, najmniejsze zakresy i mapowanie urządzeń. Powiadomienia mają docelowo godziny, priorytety i kanały, bez ukrytej wysyłki. Dom/brama pozostają za osobnymi zgodami. n8n sprawdź naprawdę, jeśli środowisko pozwala; sam profil Compose nie dowodzi działania.

## R06 — propozycje zmian kodu

Izolowany checkout, przeglądalny patch, testy, zatwierdzenie i rollback, brak wykonania kodu z treści rozmowy. Do czasu kompletnego przepływu zachowaj propozycje jako opis. Nie scalaj ani nie wdrażaj do produkcji poza autoryzacją.

## R07 — operacje i środowy odbiór

Retencja rozmów recepcji i analiz, odtwarzanie backupów na osobnej bazie, monitoring/alerty, aktualizacje, responsywny panel/HTTPS, Windows i Docker. Jeżeli Cloud ma dostęp do GitHub CI, sprawdź wynik wykonania, nie tylko YAML. Brak dostępu do sprzętu wpisz jako oczekujące, nie jako zaliczone.

## Wspólne warunki zamknięcia etapu

Kod działa na danych syntetycznych; brak regresji, prawdziwe sprawdzenia opisane; docs/RAPORT.md i PROJECT_STATUS.json zaktualizowane. Zachowaj pełen zakres11obszarów, konta i sprzęt jako jawne zależności. Zapisz zmiany do przeglądu/commitu. Kontynuuj najbliższe niezablokowane zadanie w ramach czasu sesji, zamiast pytać o zgodę na dalsze kodowanie.
