# Ustalenia wiążące — stan 22.10.2026

To zaakceptowane wymagania produktu i granice pracy, nie lista zaimplementowanych funkcji. Stan implementacji jest w PROJECT_STATUS.json.

| ID | Decyzja |
|---|---|
| D01 | Rozwijamy osobny JARVIS OS i integrację z AutoLogiką. Produkcyjnego repo AutoLogika-OS nie zmieniamy bez osobnej zgody. |
| D02 | Wszystkie 11 pierwotnych obszarów pozostaje w zakresie. Dostarczamy kod etapami, testy, Docker, dokumentację i stan realizacji. |
| D03 | Codex może kontynuować odwracalne prace i testy bez każdorazowego pytania o pozwolenie. Rzeczywiste pytania o brakujące zachowanie produktu są mile widziane. |
| D04 | Preferowane rozwiązania open source i niskie koszty. Sprawdzamy kod, licencje i licencje modeli; n8n jest source-available. Nie łączymy bezmyślnie całych repozytoriów. |
| D05 | Wywołanie głosowe zarówno przyciskiem, jak i hasłem Jarvis. Po aktywacji swobodny dialog bez powtarzania hasła. Koniec poleceniem lub po 30 s ciszy, czas regulowany w panelu. |
| D06 | Dom i warsztat: mikrofony/głośniki w miejscu rozmowy. Poza nimi: rozmowy telefoniczne w obie strony. Hałas, echo, prywatne wyjście i równoległe sesje wymagają projektu/testów, nie są rozwiązane samym uploadem WAV. |
| D07 | Pamięć osobista automatyczna według zasad: preferencje, sprzęt, projekty, decyzje i sposób pracy; źródła, korekta, usunięcie, nowsze ustalenia zastępują stare. „Tego nie zapamiętuj” blokuje zapis. |
| D08 | Nie zapisujemy automatycznie haseł, API keys, danych płatniczych ani prywatnych danych klientów w pamięci osobistej. Dane klientów należą do odrębnej recepcji/spraw warsztatu. |
| D09 | Numer warsztatu to SIM Play. JARVIS ma odbierać od razu. Użytkownik ma drugi numer do eskalacji; nie podał jego wartości — ustawi lokalnie w panelu. |
| D10 | Eskalacja do właściciela: kryzys albo klient bardzo nalega (ponawia prośbę i odrzuca pomoc). Zwykłe zdenerwowanie/przeklinanie nie wystarcza. Pierwszą prośbę obsługujemy pytaniem o sprawę/propozycją pomocy. |
| D11 | Dostępność właściciela ustawiana w głównym panelu: dni/godziny Europe/Warsaw, urlopy/wyjątki, ręczny/czasowy DND. Brak uzgodnionych domyślnych godzin, numerów i kalendarza świąt. |
| D12 | Kryzys nie omija godzin, urlopu ani DND. Poza dostępnością pilna sprawa i ciche powiadomienie, bez telefonu. Docelowy kanał cichych powiadomień pozostaje do konfiguracji. |
| D13 | Przed przekazaniem właściciel otrzymuje prywatne podsumowanie i może zaakceptować kontakt. Klient nie słyszy wewnętrznego briefingu. Brak odpowiedzi/odmowa → prośba o oddzwonienie, bez obietnicy godziny i bez ponawiania kontaktu w tej samej rozmowie. |
| D14 | Klienci nie mają uprawnień właściciela. Numer dzwoniącego ani głos/hasło Jarvis same nie uwierzytelniają właściciela. Brak ujawniania zlecenia tylko po numerze dzwoniącego. |
| D15 | AI nie wymyśla cen i dostępności, nie potwierdza rezerwacji bez autorytatywnych danych i uprawnionej operacji. Obecny most AutoLogiki jest tylko do odczytu. |
| D16 | Nie aktywujemy przekierowania/operatora i płatnych rozmów w ramach testów kodu. WhatsApp Business Calling wymaga osobnego sprawdzenia aktualnych warunków Twilio/Meta i aktywacji konta. |
| D17 | Fizyczna brama i inne wrażliwe urządzenia wymagają osobnego potwierdzenia. Modele/treść klienta nie mogą obchodzić reguł backendu ani wykonywać kodu. |
| D18 | Zmiany zachowania przez rozmowę mają docelowo prowadzić do ustawień/automatyzacji i propozycji kodu z zatwierdzeniem, testami i rollbackiem. Dziś propozycje kodu są opisem. |
| D19 | Środa 28.10.2026: użytkownik testuje Windows i sprzęt. Do tego czasu pracujemy na syntetycznych danych i sprawdzalnych laboratoriach. |

Nie pytaj ponownie, czy właściciel chce wake-word, automatyczną pamięć, odbiór od razu lub konfigurację godzin w panelu. Nie traktuj tych decyzji jako dowodu, że funkcje już działają.
