"""Configured read-only plugin transports. No local process spawning."""
import asyncio
import os
import re
from typing import Literal
from urllib.parse import quote
from pydantic import BaseModel, ConfigDict, Field, model_validator
from jsonschema import Draft202012Validator
from . import network

class PluginConfig(BaseModel):
    model_config=ConfigDict(extra='forbid')
    endpoint: str = Field(max_length=500)
    secret_env: str | None = Field(default=None, pattern=r'^JARVIS_PLUGIN_SECRET_[A-Z0-9_]{1,60}$')
    # These operations are reviewed locally by the owner, never granted by remote annotations.
    reviewed_read_tools: list[str] = Field(default_factory=list,max_length=100)
    openapi: dict | None = None

    @model_validator(mode='after')
    def safe(self):
        network.validate_origin(self.endpoint,allow_path=True)
        if self.openapi is not None:
            network.validate_origin(self.endpoint)
            try:
                inspect_openapi(self.openapi)
            except Exception as exc:
                raise ValueError('Invalid or unsupported OpenAPI schema') from exc
        return self


def inspect_openapi(spec):
    """OpenAPI 3.x safe subset: GET, operationId, scalar path/query params; no $ref."""
    if not str(spec.get('openapi','')).startswith('3.') or not isinstance(spec.get('paths'),dict):
        raise ValueError('OpenAPI 3.x with paths required')
    def refs(value):
        if isinstance(value,dict):
            return any(k in value for k in ('$ref','$dynamicRef','$recursiveRef')) or any(refs(v) for v in value.values())
        if isinstance(value,list): return any(refs(v) for v in value)
        return False
    if refs(spec):
        raise ValueError('$ref is not supported; supply a bundled scalar schema')
    found={}
    for path,item in spec['paths'].items():
        if not re.fullmatch(r'/[A-Za-z0-9_/{}/.\-]*',path) or '..' in path or path.startswith('//') or not isinstance(item,dict):
            raise ValueError('Invalid OpenAPI path')
        for method,op in item.items():
            if method=='parameters': continue
            if method not in ('get','post','put','patch','delete','head','options','trace'):
                continue
            if method!='get': continue
            if not isinstance(op,dict) or op.get('requestBody'):
                raise ValueError('GET bodies are unsupported')
            name=op.get('operationId')
            if not name or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_.-]{0,79}',name) or name in found:
                raise ValueError('GET operationId must be unique and valid')
            params=item.get('parameters',[])+op.get('parameters',[])
            names=set()
            for param in params:
                if not isinstance(param,dict) or param.get('in') not in ('path','query') or param.get('schema',{}).get('type') not in ('string','integer','number','boolean'):
                    raise ValueError('Only scalar path/query parameters are supported')
                key=param.get('name','')
                if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]{0,60}',key) or key in names:
                    raise ValueError('Duplicate or invalid parameter name')
                names.add(key)
                if param['in']=='path' and not param.get('required'):
                    raise ValueError('Path parameters must be required')
                Draft202012Validator.check_schema(param['schema'])
            placeholders=set(re.findall(r'{([^}]+)}',path))
            if placeholders!={p['name'] for p in params if p['in']=='path'}:
                raise ValueError('Path placeholders do not match parameters')
            found[name]={'path':path,'parameters':params,'description':op.get('summary','')}
    return found


def reject_schema_refs(value):
    if isinstance(value,dict):
        if any(k in value for k in ('$ref','$dynamicRef','$recursiveRef')):
            raise ValueError('Schema references are disabled')
        for item in value.values(): reject_schema_refs(item)
    elif isinstance(value,list):
        for item in value: reject_schema_refs(item)


def bearer(config):
    if not config.secret_env: return {}
    secret=os.getenv(config.secret_env,'')
    if not secret or '\r' in secret or '\n' in secret:
        raise ValueError('Configured plugin secret is missing or invalid')
    return {'Authorization':'Bearer '+secret}


async def openapi_tools(config):
    if config.openapi is None: raise ValueError('OpenAPI schema not configured')
    operations=inspect_openapi(config.openapi)
    return [{'name':name,'description':op['description'],'read_only':True} for name,op in operations.items() if name in config.reviewed_read_tools]


async def openapi_call(config,name,arguments):
    if name not in config.reviewed_read_tools:
        raise PermissionError('Operation not reviewed for read-only use')
    operations=inspect_openapi(config.openapi or {})
    if name not in operations: raise ValueError('GET operation missing')
    op=operations[name]
    if set(arguments)-{p['name'] for p in op['parameters']}:
        raise ValueError('Unknown argument')
    path=op['path'];query={}
    for p in op['parameters']:
        key=p['name']
        if key not in arguments:
            if p.get('required'): raise ValueError('Required argument missing')
            continue
        value=arguments[key]
        Draft202012Validator(p['schema']).validate(value)
        text=str(value).lower() if isinstance(value,bool) else str(value)
        if p['in']=='path':
            if text in ('.','..') or '/' in text or '\\' in text or '%' in text or '?' in text or '#' in text or not text:
                raise ValueError('Unsafe path argument')
            path=path.replace('{'+key+'}',quote(text,safe=''))
        else: query[key]=text
    data=await network.json_request(config.endpoint,'GET',path,headers=bearer(config),params=query)
    return {'mode':'live_readonly','protocol':'openapi','data':data}


async def mcp_session(config,operation=None,arguments=None):
    from mcp import ClientSession
    from mcp.client.streamable_http import streamable_http_client
    error=None
    result=None
    async with asyncio.timeout(25):
        async with network.client(config.endpoint,headers=bearer(config),timeout=15) as client:
            async with streamable_http_client(config.endpoint,http_client=client,terminate_on_close=True) as streams:
                async with ClientSession(streams[0],streams[1]) as session:
                    await session.initialize()
                    listed=await session.list_tools()
                    tools={t.name:t for t in listed.tools if t.name in config.reviewed_read_tools}
                    if operation is None:
                        result=[{'name':t.name,'description':t.description,'inputSchema':t.inputSchema,'read_only_reviewed':True} for t in tools.values()]
                    elif operation not in tools:
                        error=PermissionError('Tool not reviewed for read-only use')
                    else:
                        try:
                            schema=tools[operation].inputSchema
                            reject_schema_refs(schema)
                            Draft202012Validator.check_schema(schema)
                            Draft202012Validator(schema).validate(arguments or {})
                        except Exception:
                            error=ValueError('Invalid or unsupported MCP arguments/schema')
                        if error is None:
                            response=await session.call_tool(operation,arguments or {})
                            result={'mode':'live_readonly','protocol':'mcp','result':response.model_dump(mode='json',exclude_none=True)}
    if error: raise error
    import json
    if len(json.dumps(result))>1024*1024: raise ValueError('MCP result exceeds 1 MiB')
    return result


async def tools(protocol,config):
    return await (openapi_tools(config) if protocol=='openapi' else mcp_session(config))


async def call(protocol,config,name,arguments):
    # No call is attempted for unreviewed tools, even to a remote MCP endpoint.
    if name not in config.reviewed_read_tools:
        raise PermissionError('Operation not reviewed for read-only use')
    return await (openapi_call(config,name,arguments) if protocol=='openapi' else mcp_session(config,name,arguments))
